import { FlatCompat } from '@eslint/eslintrc';
import eslintConfigPrettier from 'eslint-config-prettier';
//import html from 'eslint-plugin-html';
//import markdown from 'eslint-plugin-markdown';
import pluginVue from 'eslint-plugin-vue'
import js from '@eslint/js';
import typeScriptESLint from '@typescript-eslint/eslint-plugin';
import typeScriptESLintParser from '@typescript-eslint/parser';

const compat = new FlatCompat();

export default {
  parser: '@typescript-eslint/parser', // TypeScript用のパーサーを指定
  plugins: [
    '@typescript-eslint', // TypeScript用のプラグインを追加
    'vue',
    'prettier'
  ],
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended', // TypeScriptの推奨設定を適用
    'plugin:vue/vue3-recommended',
    'prettier'
  ],
  rules: {
    // 必要に応じてルールを追加
  }
};
// export default [
//   {
//     ignores: ['**/fixtures/**', '**/dist/**']
//   },
//   js.configs.recommended,
//   eslintConfigPrettier,
//   ...compat.extends('plugin:node/recommended', 'plugin:@typescript-eslint/eslint-recommended'),
//   ...pluginVue.configs['flat/recommended'],
//   {
//     plugins: {
//       typeScriptESLint,
//     },
//     languageOptions: {
//       globals: {
//         Atomics: 'readonly',
//         SharedArrayBuffer: 'readonly'
//       },
//       parser: typeScriptESLintParser,
//       parserOptions: {
//         sourceType: 'module',
//         ecmaVersion: 2020
//       }
//     },
//     rules: {
//       'no-console': 'off',
//       'no-debugger': 'error',
//       'node/no-deprecated-api': 'off',
//       'node/no-unpublished-import': 'off',
//       'node/no-unpublished-require': 'off',
//       'node/no-unsupported-features/es-syntax': 'off',
//       'no-process-exit': 'off',
//       'node/no-missing-import': 'off'
//     }
//   }
// ];